# AltervistaUserBot
Source aggiornato della guida t.me/altervistauserbot


Per sapere come utilizzare questo codice, leggere la guida, oppure seguire questa sintesi dei passaggi chiave:

1. Creare spazio web altervista
2. Attivare cloudflare, https, s2s
3. Caricare bot.php
4. Lanciare bot.php e seguire le varie istruzioni (il primo caricamento è lento)

Per fare un nuovo login, usare una cartella diversa o eliminare la sessione dalle impostazioni telegram.  

Per supporto entrare nel gruppo Telegram.
