<?php

$leggi_messaggi_in_uscita = true;

$lista_admin = [
  40955937,  //id di Bruno :D
  101374607,  //id del creatore di MadelineProto :D
  12344567,  //un id probabilmente inesistente
];
